package ducku.com.moneyhappy.model;

public class User {
    public static int id = 1;
    public static int walletid = 1;
}
